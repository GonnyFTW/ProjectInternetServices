﻿using Microsoft.AspNetCore.Mvc;
using YourNamespace.Models;
using System.Collections.Generic;
using System.Linq;
using System;

namespace YourNamespace.Controllers
{
    [ApiController]
    [Route("api/discount")]
    public class DiscountController : ControllerBase
    {
        [HttpPost]
        public IActionResult CalculateDiscount(List<Product> selectedProducts)
        {
            try
            {
                
                decimal discountAmount = CalculateDiscountLogic(selectedProducts);

               
                return Ok(new { DiscountAmount = discountAmount });
            }
            catch (Exception ex)
            {
                
                return StatusCode(500, "An error occurred while calculating the discount.");
            }
        }

        private decimal CalculateDiscountLogic(List<Product> selectedProducts)
        {
            
            var discountAmount = 0m;
            var groupedProducts = selectedProducts.GroupBy(p => p.CategoryId);
            foreach (var group in groupedProducts)
            {
                if (group.Count() > 1)
                {
                    var firstProduct = group.First();
                    discountAmount += firstProduct.Price * 0.05m;
                }
            }

            return discountAmount;
        }
    }
}
