﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ISProject.Migrations
{
    /// <inheritdoc />
    public partial class SecondaryCreation : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
