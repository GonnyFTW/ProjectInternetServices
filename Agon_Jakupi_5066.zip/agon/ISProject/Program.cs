using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.EntityFrameworkCore;
using YourNamespace.Data;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;

var builder = WebApplication.CreateBuilder(args);


builder.Services.AddRazorPages();


var connectionString = builder.Configuration.GetConnectionString("DefaultConnection");
builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseSqlServer(connectionString));

var app = builder.Build();


using (var scope = app.Services.CreateScope())
{
    var services = scope.ServiceProvider;
    try
    {
        
        string jsonData = /*lang=json*/ @"[
            {
                'Name': 'Intel Core i9-9900K',
                'Categories': ['CPU'],
                'Price': 475.99,
                'Quantity': 2,
                'Description': 'Description of Intel Core i9-9900K'
            },
            {
                'Name': 'Razer BlackWidow Keyboard',
                'Categories': ['Keyboard', 'Periphery'],
                'Price': 89.99,
                'Quantity': 10,
                'Description': 'Description of Razer BlackWidow Keyboard'
            }
        ]";

        var stockItems = JsonConvert.DeserializeObject<List<StockItem>>(jsonData);

       
    }
    catch (Exception ex)
    {
       
        Console.WriteLine("An error occurred during stock import: " + ex.Message);
    }
}


if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error");
    
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseAuthorization();

app.MapRazorPages();

app.Run();
