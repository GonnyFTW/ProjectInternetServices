﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace YourNamespace.Models
{
    public class Product
    {
        [Key]
        public int ProductId { get; set; }

        [Required(ErrorMessage = "The Name field is required")]
        public string Name { get; set; }

        public string Description { get; set; }

        [Required(ErrorMessage = "The Price field is required")]
        [Column(TypeName = "decimal(18, 2)")]
        public decimal Price { get; set; }

        
        public ICollection<Category> Categories { get; set; }  

        public int Quantity { get; set; }
        public object CategoryId { get; internal set; }
    }
}
