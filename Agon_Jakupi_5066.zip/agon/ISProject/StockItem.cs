﻿using System.Collections.Generic;

public class StockItem
{
    public string Name { get; set; }
    public List<string> Categories { get; set; }
    public decimal Price { get; set; }
    public int Quantity { get; set; }
    public string Description { get; set; }
}
