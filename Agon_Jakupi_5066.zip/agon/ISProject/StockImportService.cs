﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using YourNamespace.Data;
using YourNamespace.Models;

namespace YourNamespace.Services
{
    public class StockImportService
    {
        private readonly AppDbContext _context;

        public StockImportService(AppDbContext context)
        {
            _context = context;
        }

        public void ImportStock(string jsonFilePath)
        {
            try
            {
               
                string jsonData = File.ReadAllText(jsonFilePath);

               
                List<StockItem> stockItems = JsonConvert.DeserializeObject<List<StockItem>>(jsonData);

               
                foreach (var item in stockItems)
                {
                   
                    Product product = _context.Products.Find(item.Name);
                    if (product == null)
                    {
                        
                        product = new Product
                        {
                            Name = item.Name,
                            Description = item.Description,
                            Price = item.Price
                           
                        };
                        _context.Products.Add(product);
                    }

                   
                    foreach (var categoryName in item.Categories)
                    {
                        Category category = _context.Categories.Find(categoryName);
                        if (category == null)
                        {
                            category = new Category
                            {
                                Name = categoryName
                            };
                            _context.Categories.Add(category);
                        }

                        product.Categories.Add(category);
                    }

                    product.Quantity = item.Quantity;
                }

                _context.SaveChanges();
            }
            catch (Exception ex)
            {
                Console.WriteLine("An error occurred while importing stock information: " + ex.Message);
            }
        }
    }

    public class StockItem
    {
        public string Name { get; set; }
        public List<string> Categories { get; set; }
        public decimal Price { get; set; }
        public int Quantity { get; set; }
        public string Description { get; set; }
    }
}
